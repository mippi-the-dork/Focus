# Editor Interaction and Transform Gizmos

Focus integrates with the Level Editor's selection, command, and movement systems without replacing the active transform gizmo. The plugin targets Unreal Engine 5.8.x on Windows 64-bit.

## Editor mode

`UFocusEditorMode` is a lightweight editor mode that enforces the following protection policies:

- `IsSelectionDisallowed`: rejects normal viewport selection of Selection-Locked Actors while permitting World Outliner selection through its Slate widget-path exception.
- `ProcessEditDelete` and `ProcessEditCut`: consume these commands when the selection contains an Edit-Locked Actor.
- `IsCompatibleWith`: permits Focus to remain active alongside other editor modes.

The class derives from `UEdMode`. It does **not** implement `ILegacyEdModeViewportInterface` or intercept the legacy `InputDelta` path. Focus consequently does not request the legacy gizmo system through its editor-mode interface.

## Transform protection

The Transform Lock and Edit Lock controls use several independent safeguards:

- Native Actor movement locking via `SetLockLocation`.
- `FFocusTransformGuard`, which tracks movement, component transforms, property-change notifications, and transactions.
- Standard Details-panel and editor-command restrictions for protected properties and operations.

The transform guard responds to engine movement notifications and restores protected component transforms when applicable. Scripts and specialized editor tools that bypass these notifications are outside Focus's guaranteed interaction coverage.

The editor mode does not override which gizmo the user has selected. Modern ITF and legacy gizmo operation should both be evaluated when validating protected selection movement. The absence of the legacy-mode warning alone does not establish full Transform Lock coverage for every gizmo operation.

## Interaction behavior

- **Selection Lock:** viewport selection is blocked; World Outliner selection is permitted.
- **Transform Lock:** protects standard Actor location, rotation, and scale editing; other properties remain editable.
- **Edit Lock:** includes transform protection and guards supported Actor and Component editing commands and property edits.
- **Mixed selection:** protection applies to locked Actors while unprotected Actors remain editable, subject to the standard command guards.
- **Solo and visibility:** viewport isolation and visibility settings are independent of transform gizmo selection.

## Verification checklist

- On startup with Focus enabled, the Output Log should not report that the `FOCUS` mode requires legacy gizmos and controls.
- With an unlocked Actor, verify move, rotate, scale, snapping, coordinate-space changes, and Undo/Redo using the active ITF gizmo.
- With a Transform-Locked Actor, verify move, rotate, scale, Details transforms, parent/child motion, and mixed locked/unlocked selections.
- With an Edit-Locked Actor, verify protected property controls, component operations, Cut/Delete, and Undo/Redo.
- Verify Selection Lock still permits Outliner selection, including multi-selection, while blocking normal viewport selection.
- Repeat with the legacy gizmo, and with other Outliner plugins enabled.

This document describes the intended code behavior and test coverage. Engine-side ITF event routing must be verified in a running Unreal Engine 5.8.3 editor before treating a particular transform workflow as regression-tested.
